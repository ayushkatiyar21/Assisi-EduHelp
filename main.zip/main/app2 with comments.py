"""
Assisi EduHelp - Vision + Chat Desktop App (CustomTkinter)

This program creates a study helper style GUI where a user can:
  - Type a question (text)
  - Optionally upload an image (e.g., a photo of a math problem)
  - Send the request to a language model (via OpenRouter API)
  - See the streamed response appear in a chat-like interface
  - Render (basic) SymPy pretty printed expressions if the message starts with:  sympy:<expression>

"""

import os
import base64
import threading
from tkinter import filedialog, messagebox  # Native Tkinter helpers for dialogs/popups

# 3rd party GUI and image libraries
import customtkinter as ctk               # A modern themed variant of Tkinter widgets
from PIL import Image, ImageOps           # Pillow for image loading/resizing

# SymPy for optional pretty printing of math expressions
import sympy as sp

# OpenRouter (OpenAI-compatible) SDK
import openai
from openai import OpenAI

# ---------------- Configuration Section ----------------
# WARNING: Hard‑coding API keys is unsafe. Prefer:
#   API_KEY = os.environ.get("OPENROUTER_API_KEY")
# and set an environment variable instead.
API_KEY = "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"
API_MODEL = "google/gemma-3-27b-it:free"   # Chosen model name (supports text + basic abilities)
BASE_URL = "https://openrouter.ai/api/v1"  # OpenRouter base URL

UI_SCALE = 1.35  # Global scaling for UI size (makes widgets bigger on high‑DPI displays)
RESAMPLE_BEST = getattr(Image, "LANCZOS", Image.BICUBIC)  # Best available resize filter


class VisionChatApp:
    """
    Main application class.

    Organizes:
      - Window setup
      - Color theme
      - Chat display
      - Input area (message box + upload button)
      - Streaming of model responses
      - Optional SymPy pretty printing for math
    """

    def __init__(self, root: ctk.CTk):
        # Store root (main window) and basic window properties
        self.root = root
        self.root.title("Assisi EduHelp")
        self.root.geometry("920x780")
        self.root.minsize(720, 600)

        # Configure appearance/theme using CustomTkinter helpers
        ctk.set_appearance_mode("Light")
        ctk.set_default_color_theme("blue")
        ctk.set_window_scaling(UI_SCALE)   # Scales the entire window
        ctk.set_widget_scaling(UI_SCALE)   # Scales each widget

        # A central palette of colors so we can easily change the "look" later
        self.colors = {
            "bg": "#F5F7FB",
            "surface": "#FFFFFF",
            "surface_alt": "#F2F5FA",
            "border": "#E5E7EB",
            "primary": "#2563EB",
            "primary_hover": "#1D4ED8",
            "muted": "#6B7280",
            "user_bubble": "#E8F1FF",
            "user_border": "#CFE3FF",
            "user_text": "#0F172A",
            "bot_bubble": "#FFF6E5",
            "bot_border": "#FDE6BF",
            "bot_text": "#1F2937",
            "system_bubble": "#EEF2FF",
            "system_border": "#DDE3FF",
            "system_text": "#111827",
        }

        # --------------- Runtime State Variables ---------------
        self.image_path = None             # Full path of user‑selected image (if any)
        self.image_preview = None          # Cached CustomTkinter image object for thumbnail preview
        self.thinking = False              # Whether the "loading/progress" indicator is shown
        self._streaming = False            # Whether we are currently streaming model output
        self._stream_buffer = ""           # Accumulated streamed text so far
        self._cursor_visible = True        # Blinking cursor state for streaming effect
        self._cursor_glyph = "│"           # Character used as a blinking cursor
        self._stream_label = None          # The label widget where streaming text is displayed
        self._img_cache: list[ctk.CTkImage] = []  # Prevent images from being garbage collected
        self.client: OpenAI | None = None  # API client (None if init failed)
        self.wraplength = int(720 * UI_SCALE)     # Max line width for text wrapping
        self.placeholder_image = self._make_placeholder_image((96, 96))  # Shown when no image chosen

        # Apply background color and build the UI structure
        self.root.configure(fg_color=self.colors["bg"])
        self._build_header()
        self._build_body()
        self._build_input_card()

        # Display a welcome/system message
        self.add_message(
            "Bot",
            "Hello! I’m Assisi EduHelp—your study companion. Type a question or attach a photo of your problem, and I’ll guide you step by step."
        )

        # Initialize the OpenAI/OpenRouter client
        self._init_client()

    # ---------------- UI Construction Methods ----------------
    def _build_header(self):
        """
        Builds the top header area that currently just displays the logo.
        """
        self.header = ctk.CTkFrame(
            self.root,
            fg_color=self.colors["surface"],
            corner_radius=0,
            border_width=0,
        )
        self.header.pack(fill="x")

        container = ctk.CTkFrame(self.header, fg_color="transparent")
        container.pack(fill="x", padx=16, pady=10)

        left = ctk.CTkFrame(container, fg_color="transparent")
        left.pack(side="left")

        # Try to locate a logo file (PNG preferred; fallback to JPG)
        logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if not os.path.exists(logo_path):
            alt_logo = os.path.join(os.path.dirname(__file__), "logo.jpg")
            logo_path = alt_logo if os.path.exists(alt_logo) else None

        # Load and scale the logo if it exists
        if logo_path:
            try:
                logo_img = Image.open(logo_path)
                logo_target_size = (int(350 * UI_SCALE), int(102 * UI_SCALE))
                logo_img = ImageOps.contain(logo_img, logo_target_size, method=RESAMPLE_BEST)
                logo_logical_size = (
                    max(1, int(logo_img.width / UI_SCALE)),
                    max(1, int(logo_img.height / UI_SCALE))
                )
                self.logo_ctk_img = ctk.CTkImage(
                    light_image=logo_img.copy(),
                    dark_image=logo_img.copy(),
                    size=logo_logical_size
                )
                ctk.CTkLabel(left, image=self.logo_ctk_img, text="").pack(side="left", padx=(2, 10))
            except Exception:
                self.logo_ctk_img = None  # Silently fail; header still works

        # Thin dividing line under the header
        divider = ctk.CTkFrame(self.root, height=1, fg_color=self.colors["border"], corner_radius=0)
        divider.pack(fill="x")

    def _build_body(self):
        """
        Creates the main chat area:
          - Outer card frame
          - Scrollable frame inside where chat bubbles are added
        """
        self.chat_card = ctk.CTkFrame(
            self.root,
            fg_color=self.colors["surface"],
            corner_radius=16,
            border_width=1,
            border_color=self.colors["border"],
        )
        self.chat_card.pack(fill="both", expand=True, padx=16, pady=(12, 8))

        # Scrollable container for messages (bubbles)
        self.chat_scroll = ctk.CTkScrollableFrame(
            self.chat_card,
            fg_color="transparent",
        )
        self.chat_scroll.pack(fill="both", expand=True, padx=12, pady=12)

        self._message_widgets = []  # Keep references to message bubble frames

    def _build_input_card(self):
        """
        Builds the bottom input area:
          - Optional image preview row (only appears when an image is chosen)
          - Text entry box
          - Upload + Send buttons
          - Hidden progress bar row for 'thinking' state
        """
        self.input_card = ctk.CTkFrame(
            self.root,
            fg_color=self.colors["surface"],
            corner_radius=16,
            border_width=1,
            border_color=self.colors["border"],
        )
        self.input_card.pack(fill="x", padx=16, pady=(0, 16))

        # Row shown only when an image is selected
        self.preview_row = ctk.CTkFrame(self.input_card, fg_color="transparent")

        # Thumbnail preview container
        preview_box = ctk.CTkFrame(
            self.preview_row,
            fg_color=self.colors["surface_alt"],
            corner_radius=12,
            border_width=1,
            border_color=self.colors["border"],
            width=96,
            height=96,
        )
        preview_box.pack_propagate(False)
        preview_box.pack(side="left", padx=(12, 10), pady=(12, 6))

        self.preview_label = ctk.CTkLabel(preview_box, text="", text_color=self.colors["muted"])
        self.preview_label.pack(expand=True)

        self.image_status = ctk.CTkLabel(
            self.preview_row,
            text="No image selected.",
            anchor="w",
            text_color=self.colors["muted"],
        )
        self.image_status.pack(side="left", fill="x", expand=True, padx=(2, 0), pady=(12, 6))

        # Bottom row with entry + buttons
        bottom_row = ctk.CTkFrame(self.input_card, fg_color="transparent")
        bottom_row.pack(fill="x", padx=12, pady=(6, 12))

        # Text entry for the user's question/prompt
        self.msg_entry = ctk.CTkEntry(
            bottom_row,
            placeholder_text="Type your message...",
            height=46,
            corner_radius=12,
            border_width=1,
            border_color=self.colors["border"],
        )
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        # Pressing Enter triggers sending (runs in separate thread)
        self.msg_entry.bind("<Return>", self.start_query_thread)

        # Button to choose an image file
        self.upload_button = ctk.CTkButton(
            bottom_row,
            text="Upload",
            fg_color=self.colors["primary"],
            hover_color=self.colors["primary_hover"],
            corner_radius=10,
            command=self.browse_image,
            width=110,
        )
        self.upload_button.pack(side="left", padx=(0, 8))

        # Button to send message (and image if selected)
        self.send_button = ctk.CTkButton(
            bottom_row,
            text="Send",
            fg_color=self.colors["primary"],
            hover_color=self.colors["primary_hover"],
            corner_radius=10,
            command=self.start_query_thread,
            width=110,
        )
        self.send_button.pack(side="left")

        # Hidden progress/animation row (only shown when waiting for model)
        self.progress_row = ctk.CTkFrame(self.input_card, fg_color="transparent")
        self.progress_bar = ctk.CTkProgressBar(
            self.progress_row,
            mode="indeterminate",
            width=260,
            progress_color=self.colors["primary"],
        )

    # ---------------- Utility & Helper Methods ----------------
    def autoscroll(self):
        """
        Scroll the chat view to the bottom whenever a new message is added.
        """
        if self._message_widgets:
            try:
                self.chat_scroll._parent_canvas.yview_moveto(1.0)
            except Exception:
                pass  # If the canvas isn't ready, ignore

    def _bubble(self, text: str, kind: str):
        """
        Create and display a standard text bubble.

        kind: "user", "bot", or "system" decides colors and alignment.
        Also supports a "sympy:" prefix so you can type:
            sympy: integrate(sin(x)**2, x)
        to show a pretty printed version of the expression.
        """
        bg, border, txt, align = self._bubble_colors(kind)

        # Row wrapper to allow left/right alignment
        row = ctk.CTkFrame(self.chat_scroll, fg_color="transparent")
        row.pack(fill="x", padx=4, pady=6)

        # Actual bubble frame
        bubble = ctk.CTkFrame(
            row,
            fg_color=bg,
            corner_radius=14,
            border_width=1,
            border_color=border,
        )
        bubble.pack(side="right" if align == "right" else "left", padx=6)

        # Determine if we should pretty print (SymPy) or just display raw text
        pretty_text = None
        if text.strip().startswith("sympy:"):
            expr_str = text.strip()[6:].strip()
            try:
                expr = sp.sympify(expr_str)  # Convert string to a SymPy expression
                pretty_text = sp.pretty(expr, use_unicode=True)
            except Exception:
                pretty_text = "Error parsing expression."

        if pretty_text:
            # Use monospaced font for better alignment of SymPy box characters
            label = ctk.CTkLabel(
                bubble,
                text=pretty_text,
                justify="left",
                anchor="w",
                text_color=txt,
                font=ctk.CTkFont(size=15, family="Consolas"),
            )
        else:
            label = ctk.CTkLabel(
                bubble,
                text=text,
                justify="left",
                wraplength=self.wraplength,
                anchor="w",
                text_color=txt,
                font=ctk.CTkFont(size=14),
            )

        label.pack(padx=12, pady=10)
        self._message_widgets.append(bubble)
        self.autoscroll()
        return label

    def _bubble_with_image(self, text: str, kind: str, image_path: str):
        """
        Create a chat bubble that includes a (resized) image at the top, then optional text.
        """
        bg, border, txt, align = self._bubble_colors(kind)
        row = ctk.CTkFrame(self.chat_scroll, fg_color="transparent")
        row.pack(fill="x", padx=4, pady=6)

        bubble = ctk.CTkFrame(
            row,
            fg_color=bg,
            corner_radius=14,
            border_width=1,
            border_color=border,
        )
        bubble.pack(side="right" if align == "right" else "left", padx=6)

        try:
            pil = Image.open(image_path)
            # Limit image size so it fits nicely inside bubble
            max_w_logical = int(420 * UI_SCALE)
            max_h_logical = int(320 * UI_SCALE)
            ctk_img = self._prepare_ctk_image(pil, (max_w_logical, max_h_logical))
            ctk.CTkLabel(bubble, image=ctk_img, text="").pack(padx=10, pady=(10, 6))
        except Exception as e:
            # Append an error note to the text if preview fails
            text = f"{text}\n\n[Image preview unavailable: {e}]"

        if text:
            txt_label = ctk.CTkLabel(
                bubble,
                text=text,
                justify="left",
                wraplength=self.wraplength,
                anchor="w",
                text_color=txt,
                font=ctk.CTkFont(size=14),
            )
            txt_label.pack(padx=12, pady=(0, 10))

        self._message_widgets.append(bubble)
        self.autoscroll()

    def _prepare_ctk_image(self, pil_img: Image.Image, max_logical_size: tuple[int, int]) -> ctk.CTkImage:
        """
        Resize an image to fit the given maximum (logical) size while maintaining aspect ratio.
        Returns a CustomTkinter image object safe to place in labels.
        """
        max_w_logical, max_h_logical = max_logical_size
        target_px_size = (max_w_logical, max_h_logical)
        img = pil_img.copy()
        img = ImageOps.contain(img, target_px_size, method=RESAMPLE_BEST)
        # Convert from physical pixels to logical size for CTk scaling
        logical_w = max(1, int(round(img.width / UI_SCALE)))
        logical_h = max(1, int(round(img.height / UI_SCALE)))
        return self._to_ctk_image(img, (logical_w, logical_h))

    def _bubble_colors(self, kind: str):
        """
        Return (background, border, text_color, alignment_side) for a bubble type.
        """
        if kind == "user":
            return (
                self.colors["user_bubble"],
                self.colors["user_border"],
                self.colors["user_text"],
                "right",
            )
        if kind == "system":
            return (
                self.colors["system_bubble"],
                self.colors["system_border"],
                self.colors["system_text"],
                "left",
            )
        # Default: bot
        return (
            self.colors["bot_bubble"],
            self.colors["bot_border"],
            self.colors["bot_text"],
            "left",
        )

    def add_message(self, sender: str, message: str):
        """
        Public helper to add a message to chat by sender name.
        - 'User' shows right-aligned (blue-ish)
        - 'Bot' / others show left-aligned
        - 'System' uses neutral styling
        """
        s = sender.lower()
        if s == "user":
            self._bubble(message, "user")
        elif s == "system":
            self._bubble(message, "system")
        else:
            self._bubble(message, "bot")

    def _hide_preview_row(self, reset=False):
        """
        Hide the preview row (used after sending or clearing the image).
        If reset=True, also restore "No image selected" text.
        """
        if hasattr(self, "preview_row") and self.preview_row.winfo_manager():
            self.preview_row.pack_forget()
        if reset:
            try:
                self.image_status.configure(text="No image selected.", text_color=self.colors["muted"])
            except Exception:
                pass
            # Defer UI update so Tkinter doesn't complain during layout changes
            self.root.after_idle(lambda: self.preview_label.configure(image=self.placeholder_image, text="No image"))
        self.image_preview = None

    # ---------------- Thinking / Streaming Visuals ----------------
    def show_thinking(self):
        """
        Show the progress bar (spinner effect) while waiting for API response.
        """
        if not self.thinking:
            self.thinking = True
            self.progress_row.pack(pady=(0, 10))
            self.progress_bar.pack()
            self.progress_bar.start()

    def hide_thinking(self):
        """
        Hide and stop the progress bar.
        """
        if self.thinking:
            self.progress_bar.stop()
            self.progress_bar.pack_forget()
            self.progress_row.pack_forget()
            self.thinking = False

    def begin_streaming(self):
        """
        Prepare to receive streaming text from the model:
          - Create an empty bot bubble
          - Start a blinking cursor animation
        """
        self._streaming = True
        self._stream_buffer = ""
        self._cursor_visible = True
        self._stream_label = self._bubble("", "bot")
        self.hide_thinking()
        self._animate_stream_update()

    def _animate_stream_update(self):
        """
        Blink the cursor by toggling visibility at fixed intervals.
        Uses root.after(...) for a recurring callback (non-blocking).
        """
        if not self._streaming or self._stream_label is None:
            return
        try:
            cursor = f" {self._cursor_glyph}" if self._cursor_visible else ""
            self._stream_label.configure(text=self._stream_buffer + cursor)
        except Exception:
            pass
        self._cursor_visible = not self._cursor_visible
        # Schedule next blink in 120 ms
        self.root.after(120, self._animate_stream_update)

    def append_stream_text(self, text_chunk: str):
        """
        Add new incoming text to the streaming buffer.
        The blink loop (above) updates the visible label.
        """
        if text_chunk:
            self._stream_buffer += text_chunk

    def end_streaming(self):
        """
        Finalize streaming: remove the cursor and mark streaming as finished.
        """
        self._streaming = False
        if self._stream_label is not None:
            try:
                self._stream_label.configure(text=self._stream_buffer)
            except Exception:
                pass
        self._finish_request_cleanup()

    # ---------------- API Client & Image Helpers ----------------
    def _init_client(self):
        """
        Initialize the OpenAI-compatible client object.
        If this fails (bad key, network), we store None and post a system message.
        """
        try:
            self.client = OpenAI(base_url=BASE_URL, api_key=API_KEY)
        except Exception as e:
            self.client = None
            self.add_message("System", f"Failed to connect to the model: {e}")

    def _to_ctk_image(self, pil_img: Image.Image, size: tuple[int, int]) -> ctk.CTkImage:
        """
        Convert a Pillow image to a CTkImage and keep a reference to prevent garbage collection.
        """
        light = pil_img.copy()
        dark = pil_img.copy()
        cimg = ctk.CTkImage(light_image=light, dark_image=dark, size=size)
        self._img_cache.append(cimg)
        # Limit cache size (avoid memory bloat if many images are used)
        if len(self._img_cache) > 8:
            self._img_cache = self._img_cache[-8:]
        return cimg

    def _make_placeholder_image(self, size: tuple[int, int]) -> ctk.CTkImage:
        """
        Create a simple plain rectangle shown when no image has been selected yet.
        """
        w, h = size
        from PIL import Image  # Local import to emphasize it's only used here
        light_bg = Image.new("RGBA", (w, h), (242, 245, 250, 255))
        dark_bg = Image.new("RGBA", (w, h), (30, 41, 59, 255))
        return ctk.CTkImage(light_image=light_bg, dark_image=dark_bg, size=size)

    def browse_image(self):
        """
        Open a file dialog so the user can choose an image.
        After selection:
          - Show preview row (if hidden)
          - Display thumbnail
        """
        file_path = filedialog.askopenfilename(
            title="Select an Image",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.gif")]
        )
        if not file_path:
            # User canceled selection
            self.image_path = None
            self._hide_preview_row(reset=True)
            return

        self.image_path = file_path
        self.image_status.configure(text=f"Selected: {os.path.basename(file_path)}", text_color="#111827")

        # Show the preview row if it's currently hidden
        if not self.preview_row.winfo_manager():
            self.preview_row.pack(fill="x", padx=12, pady=(12, 6))

        try:
            pil = Image.open(file_path)
            ctk_img = self._prepare_ctk_image(pil, (int(96 * UI_SCALE), int(96 * UI_SCALE)))
            self.image_preview = ctk_img
            # Use after_idle to avoid flicker or layout race conditions
            self.root.after_idle(lambda: self.preview_label.configure(image=self.image_preview, text=""))
        except Exception as e:
            messagebox.showerror("Image Error", f"Could not load preview: {e}")
            self.root.after_idle(lambda: self.preview_label.configure(image=self.placeholder_image, text="No image"))
            self._hide_preview_row(reset=True)
            self.image_preview = None

    @staticmethod
    def _guess_mime_type(path: str) -> str:
        """
        Return an appropriate MIME type string based on file extension.
        """
        ext = os.path.splitext(path)[1].lower()
        return {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
            ".gif": "image/gif",
        }.get(ext, "image/jpeg")

    @staticmethod
    def encode_image_to_base64(path: str) -> str | None:
        """
        Read an image file and convert its bytes to a Base64 text string
        that can be embedded directly in the API request.
        """
        try:
            with open(path, "rb") as f:
                return base64.b64encode(f.read()).decode("utf-8")
        except Exception as e:
            messagebox.showerror("File Error", f"Could not read or encode the image: {e}")
            return None

    # ---------------- Sending & Streaming the Request ----------------
    def start_query_thread(self, event=None):
        """
        Called when user presses Enter or clicks 'Send'.
        Starts a background thread so the GUI stays responsive while the API call happens.
        """
        user_input = (self.msg_entry.get() or "").strip()

        # Disallow empty request if no image is provided
        if not user_input and not self.image_path:
            messagebox.showwarning("Input Error", "Please enter a question or upload an image.")
            return

        if self.client is None:
            self.add_message("System", "OpenAI client not configured.")
            return

        # Add user's message to chat (with image if present)
        if self.image_path:
            self._bubble_with_image(user_input if user_input else "[Image Query]", "user", self.image_path)
            self._hide_preview_row(reset=False)  # Keep the image until we send
        else:
            self.add_message("User", user_input)

        # Clear entry and disable inputs during request
        self.msg_entry.delete(0, "end")
        self.msg_entry.configure(state="disabled")
        self.send_button.configure(state="disabled")
        self.upload_button.configure(state="disabled")
        self.show_thinking()

        # Start the request in a separate thread
        t = threading.Thread(target=self.submit_query_streaming, args=(user_input,))
        t.daemon = True   # Daemon so it won't block app exit
        t.start()

    def submit_query_streaming(self, prompt: str):
        """
        Worker thread target:
          - Build the message payload
          - Include image (Base64) if present
          - Stream the response and append chunks to the chat bubble
        """
        final_prompt = prompt if (prompt or "").strip() else "What is in this image?"
        messages = [{"role": "user", "content": []}]
        # Add the text part
        messages[0]["content"].append({"type": "text", "text": final_prompt})

        # Add image part if user selected one
        if self.image_path:
            base64_image = self.encode_image_to_base64(self.image_path)
            if not base64_image:
                # We schedule GUI update on main thread using root.after
                self.root.after(0, self.update_chat_with_response, "Error: Could not encode image.")
                return
            mime = self._guess_mime_type(self.image_path)
            messages[0]["content"].append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{base64_image}"}
            })

        # Switch UI into streaming mode (on main thread)
        self.root.after(0, self.begin_streaming)

        try:
            # Make the streaming API call
            stream = self.client.chat.completions.create(
                model=API_MODEL,
                messages=messages,
                max_tokens=1024,  # Upper bound on response length
                stream=True,
            )

            # Iterate over incremental chunks returned by the API
            for chunk in stream:
                try:
                    delta = None
                    # Different object forms possible depending on SDK version
                    if hasattr(chunk.choices[0], "delta"):
                        delta = chunk.choices[0].delta
                    elif isinstance(chunk.choices[0], dict) and "delta" in chunk.choices[0]:
                        delta = chunk.choices[0]["delta"]

                    text_part = ""
                    if isinstance(delta, dict):
                        text_part = delta.get("content") or ""
                    else:
                        text_part = getattr(delta, "content", None) or ""

                    # Some providers put text in "text" field instead
                    if not text_part and hasattr(chunk.choices[0], "text"):
                        text_part = getattr(chunk.choices[0], "text") or ""
                    if not text_part and isinstance(chunk.choices[0], dict):
                        text_part = chunk.choices[0].get("text") or ""

                    if text_part:
                        # Accumulate text in buffer (GUI updated by blink loop)
                        self.append_stream_text(text_part)
                except Exception:
                    # Ignore malformed chunks; continue streaming
                    continue

            # After stream ends, finalize on main thread
            self.root.after(0, self.end_streaming)

        except openai.APIStatusError as e:
            error_message = f"API Error: {e.status_code}\n{e.response.text}"
            self.root.after(0, self.update_chat_with_response, error_message)
        except Exception as e:
            error_message = f"An unexpected error occurred: {e}"
            self.root.after(0, self.update_chat_with_response, error_message)

    # ---------------- Cleanup & Finalization ----------------
    def _finish_request_cleanup(self):
        """
        Re-enable inputs and reset temporary state after a request finishes.
        """
        self.image_path = None
        self._hide_preview_row(reset=True)
        self.image_preview = None
        self.msg_entry.configure(state="normal")
        self.send_button.configure(state="normal")
        self.upload_button.configure(state="normal")
        self.msg_entry.focus_set()

    def update_chat_with_response(self, response: str):
        """
        Called when a non-streaming fallback or an error happens.
        Also used to ensure any thinking indicator stops properly.
        """
        try:
            self.hide_thinking()
            if self._streaming:
                self.end_streaming()
            self.add_message("Bot", response)
        finally:
            self._finish_request_cleanup()


# Standard "entry point" guard: only run GUI if this file is executed directly
if __name__ == "__main__":
    app_root = ctk.CTk()
    app = VisionChatApp(app_root)
    app_root.mainloop()
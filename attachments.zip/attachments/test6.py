import os
import base64
import threading
from tkinter import filedialog, messagebox

# 3rd party
import customtkinter as ctk
from PIL import Image

# OpenRouter via OpenAI SDK
import openai
from openai import OpenAI


"""
Vision Chat App (CustomTkinter Edition)

Modernized the original Tkinter app using CustomTkinter for a cleaner, modern UI,
while preserving the original functionality (image upload + multimodal chat via OpenRouter).

Setup:
- pip install customtkinter pillow openai

Environment:
- Set OPENROUTER_API_KEY in your environment.
  Example (macOS/Linux): export OPENROUTER_API_KEY="sk-or-..."
  Example (Windows PowerShell): $env:OPENROUTER_API_KEY="sk-or-..."

Optional:
- Put a 'logo.png' or 'logo.jpg' in the same directory to show a header logo.

Notes:
- The API key is intentionally NOT hard-coded here for security.
- This app uses the OpenAI Python SDK pointed at OpenRouter.
"""

# --- Configuration ---
API_MODEL = os.environ.get("OPENROUTER_MODEL", "google/gemma-3-27b-it:free")
API_KEY = os.environ.get("OPENROUTER_API_KEY")
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# --- OpenAI Client Setup for OpenRouter ---
client = None
try:
    if API_KEY:
        client = OpenAI(base_url=OPENROUTER_BASE_URL, api_key=API_KEY)
except Exception as e:
    # Fallback to None; we'll show an error later in the UI
    client = None


class VisionChatApp:
    def __init__(self, root: ctk.CTk):
        self.root = root
        self.root.title("Vision Chat (Modern)")
        self.root.geometry("880x760")

        # Appearance and theme
        ctk.set_appearance_mode("System")  # Light/Dark/System
        ctk.set_default_color_theme("blue")  # "blue", "dark-blue", "green"

        # State
        self.image_path = None
        self.image_preview = None  # CTkImage for preview
        self.thinking = False

        # Colors for bubbles
        self.user_fg = ("#0b132b", "#e5e7eb")   # text color (light, dark)
        self.bot_fg = ("#1f2937", "#d1d5db")
        self.user_bg = ("#e0f2fe", "#0b3a53")   # bubble color
        self.bot_bg = ("#fff7ed", "#3b2f1e")

        # Header
        self._build_header()

        # Body: Chat (scrollable) + Input
        self._build_chat_area()
        self._build_input_area()

        # Initial message
        self.add_message("Bot", "Welcome! Ask a question or upload an image to discuss.")

        if client is None:
            self.add_message("System", "Error: OPENROUTER_API_KEY is not set or client initialization failed.")

    # ---------- UI Builders ----------
    def _build_header(self):
        self.header = ctk.CTkFrame(self.root, corner_radius=0)
        self.header.pack(fill="x")

        # Left cluster: logo + title
        left = ctk.CTkFrame(self.header, fg_color="transparent")
        left.pack(side="left", padx=12, pady=8)

        # Logo
        logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if not os.path.exists(logo_path):
            alt_logo = os.path.join(os.path.dirname(__file__), "logo.jpg")
            logo_path = alt_logo if os.path.exists(alt_logo) else None

        if logo_path:
            try:
                logo_img = Image.open(logo_path)
                self.logo_ctk_img = ctk.CTkImage(light_image=logo_img, dark_image=logo_img, size=(40, 40))
                ctk.CTkLabel(left, image=self.logo_ctk_img, text="").pack(side="left", padx=(6, 8))
            except Exception:
                self.logo_ctk_img = None

        ctk.CTkLabel(left, text="Vision Chat", font=ctk.CTkFont(size=20, weight="bold")).pack(side="left")

        # Right cluster: appearance switch
        right = ctk.CTkFrame(self.header, fg_color="transparent")
        right.pack(side="right", padx=12, pady=8)

        ctk.CTkLabel(right, text="Theme:").pack(side="left", padx=(0, 8))
        self.theme_switch = ctk.CTkSegmentedButton(
            right,
            values=["System", "Light", "Dark"],
            command=self._on_theme_change
        )
        self.theme_switch.set("System")
        self.theme_switch.pack(side="left")

    def _build_chat_area(self):
        self.chat_scroll = ctk.CTkScrollableFrame(self.root, label_text="", fg_color="transparent")
        self.chat_scroll.pack(fill="both", expand=True, padx=12, pady=(8, 4))

        # Keep a running list of message widgets to support autoscroll
        self._message_widgets = []

    def _build_input_area(self):
        self.input_frame = ctk.CTkFrame(self.root)
        self.input_frame.pack(fill="x", padx=12, pady=(4, 12))

        # Row 1: Image preview + status
        top_row = ctk.CTkFrame(self.input_frame, fg_color="transparent")
        top_row.pack(fill="x", pady=(8, 2))

        self.preview_label = ctk.CTkLabel(top_row, text="", width=96, height=96)
        self.preview_label.pack(side="left", padx=(0, 8))

        self.image_status = ctk.CTkLabel(top_row, text="No image selected.", anchor="w")
        self.image_status.pack(side="left", fill="x", expand=True)

        # Row 2: Entry + Buttons
        bottom_row = ctk.CTkFrame(self.input_frame, fg_color="transparent")
        bottom_row.pack(fill="x", pady=(6, 6))

        self.msg_entry = ctk.CTkEntry(bottom_row, placeholder_text="Type your message...", height=42)
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.msg_entry.bind("<Return>", self.start_query_thread)

        self.upload_button = ctk.CTkButton(bottom_row, text="Upload", command=self.browse_image)
        self.upload_button.pack(side="left", padx=(0, 6))

        self.send_button = ctk.CTkButton(bottom_row, text="Send", command=self.start_query_thread)
        self.send_button.pack(side="left")

        # Row 3: Thinking progress bar
        self.progress_row = ctk.CTkFrame(self.input_frame, fg_color="transparent")
        self.progress_bar = ctk.CTkProgressBar(self.progress_row, mode="indeterminate", width=220)
        # Hidden by default

    # ---------- UI Actions ----------
    def _on_theme_change(self, value: str):
        if value == "Light":
            ctk.set_appearance_mode("Light")
        elif value == "Dark":
            ctk.set_appearance_mode("Dark")
        else:
            ctk.set_appearance_mode("System")

    def autoscroll(self):
        # Scroll to bottom by ensuring the last widget is visible
        if self._message_widgets:
            self.chat_scroll._parent_canvas.yview_moveto(1.0)

    def _bubble(self, text: str, is_user: bool, is_system: bool = False):
        # Choose colors
        if is_system:
            fg = self.bot_fg
            bg = ("#fde68a", "#3a2e0f")
        else:
            fg = self.user_fg if is_user else self.bot_fg
            bg = self.user_bg if is_user else self.bot_bg

        # Container that will align left/right by using anchor on pack
        container = ctk.CTkFrame(self.chat_scroll, fg_color="transparent")
        container.pack(fill="x", padx=6, pady=4)

        bubble = ctk.CTkFrame(container, fg_color=bg, corner_radius=14)
        bubble.pack(side="right" if is_user else "left", padx=4)

        label = ctk.CTkLabel(
            bubble,
            text=text,
            justify="left",
            wraplength=640,
            anchor="w",
            font=ctk.CTkFont(size=14),
        )
        label.pack(padx=12, pady=8)
        self._message_widgets.append(bubble)
        self.autoscroll()

    def add_message(self, sender: str, message: str):
        sender_lower = sender.lower()
        if sender_lower == "user":
            self._bubble(message, is_user=True)
        elif sender_lower == "system":
            self._bubble(message, is_user=False, is_system=True)
        else:
            self._bubble(message, is_user=False)

    def show_thinking(self):
        if not self.thinking:
            self.thinking = True
            self.progress_row.pack(fill="x", pady=(0, 4))
            self.progress_bar.pack(side="left")
            self.progress_bar.start()

    def hide_thinking(self):
        if self.thinking:
            self.progress_bar.stop()
            self.progress_bar.pack_forget()
            self.progress_row.pack_forget()
            self.thinking = False

    # ---------- Image Handling ----------
    def browse_image(self):
        file_path = filedialog.askopenfilename(
            title="Select an Image",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.webp *.gif")]
        )
        if not file_path:
            self.image_path = None
            self.image_status.configure(text="No image selected.")
            self.preview_label.configure(image=None, text="")
            self.image_preview = None
            return

        self.image_path = file_path
        self.image_status.configure(text=f"Selected: {os.path.basename(file_path)}")

        try:
            img = Image.open(file_path)
            # Make a reasonable thumbnail size
            thumb_size = (96, 96)
            img.thumbnail(thumb_size)
            self.image_preview = ctk.CTkImage(light_image=img, dark_image=img, size=thumb_size)
            self.preview_label.configure(image=self.image_preview, text="")
        except Exception as e:
            messagebox.showerror("Image Error", f"Could not load preview: {e}")
            self.preview_label.configure(image=None, text="")
            self.image_preview = None

    @staticmethod
    def _guess_mime_type(path: str) -> str:
        ext = os.path.splitext(path)[1].lower()
        return {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
            ".gif": "image/gif",
        }.get(ext, "image/jpeg")

    @staticmethod
    def encode_image_to_base64(path: str) -> str | None:
        try:
            with open(path, "rb") as f:
                return base64.b64encode(f.read()).decode("utf-8")
        except Exception as e:
            messagebox.showerror("File Error", f"Could not read or encode the image: {e}")
            return None

    # ---------- Chat Logic ----------
    def start_query_thread(self, event=None):
        user_input = self.msg_entry.get().strip()
        if not user_input and not self.image_path:
            messagebox.showwarning("Input Error", "Please enter a question or upload an image.")
            return

        self.add_message("User", user_input if user_input else "[Image Query]")
        self.msg_entry.delete(0, "end")

        # Disable inputs while processing
        self.msg_entry.configure(state="disabled")
        self.send_button.configure(state="disabled")
        self.upload_button.configure(state="disabled")

        self.show_thinking()

        t = threading.Thread(target=self.submit_query, args=(user_input,))
        t.daemon = True
        t.start()

    def submit_query(self, prompt: str):
        if client is None:
            self.root.after(0, self.update_chat_with_response, "Error: OpenAI client not configured. Set OPENROUTER_API_KEY.")
            return

        final_prompt = prompt if prompt.strip() else "What is in this image?"

        messages = [{"role": "user", "content": []}]
        messages[0]["content"].append({"type": "text", "text": final_prompt})

        # Attach image if provided
        if self.image_path:
            base64_image = self.encode_image_to_base64(self.image_path)
            if not base64_image:
                self.root.after(0, self.update_chat_with_response, "Error: Could not encode image.")
                return
            mime = self._guess_mime_type(self.image_path)
            messages[0]["content"].append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{base64_image}"}
            })

        try:
            completion = client.chat.completions.create(
                model=API_MODEL,
                messages=messages,
                max_tokens=1024,
            )
            response_content = completion.choices[0].message.content
            self.root.after(0, self.update_chat_with_response, response_content)
        except openai.APIStatusError as e:
            error_message = f"API Error: {e.status_code}\n{e.response.text}"
            self.root.after(0, self.update_chat_with_response, error_message)
        except Exception as e:
            error_message = f"An unexpected error occurred: {e}"
            self.root.after(0, self.update_chat_with_response, error_message)

    def update_chat_with_response(self, response: str):
        try:
            self.hide_thinking()
            self.add_message("Bot", response)

            # Reset image state
            self.image_path = None
            self.image_status.configure(text="No image selected.")
            self.preview_label.configure(image=None, text="")
            self.image_preview = None
        finally:
            # Re-enable inputs
            self.msg_entry.configure(state="normal")
            self.send_button.configure(state="normal")
            self.upload_button.configure(state="normal")
            self.msg_entry.focus_set()


if __name__ == "__main__":
    app_root = ctk.CTk()
    app = VisionChatApp(app_root)
    app_root.mainloop()